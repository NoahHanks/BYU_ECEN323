source /tools/Xilinx/Vivado/2019.2/settings64.sh
