# Lab 1

The lab write-up for Lab 1 is located at the following [URL](https://ecen323wiki.groups.et.byu.net/labs/lab-01/).

