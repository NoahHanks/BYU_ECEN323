# Lab 3

The lab write-up for Lab 3 is located at the following [URL](https://ecen323wiki.groups.et.byu.net/labs/lab-03/).

