# Lab 2 

The lab write-up for Lab 2 is located at the following [URL](https://ecen323wiki.groups.et.byu.net/labs/lab-02/).

