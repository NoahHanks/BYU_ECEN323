source D:/Xilinx/Vivado/2019.1/settings64.sh 
